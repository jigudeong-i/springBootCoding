package com.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
